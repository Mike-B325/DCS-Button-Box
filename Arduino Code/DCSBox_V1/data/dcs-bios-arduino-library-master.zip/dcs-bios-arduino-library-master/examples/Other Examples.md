Here are some other examples of dcs-bios in action:

- [RobinMLi/DCS-CDU-Display: Proof of concept - A cheap solution to create a DCS A-10C CDU display. (github.com)](https://github.com/RobinMLi/DCS-CDU-Display)
- https://github.com/talbotmcinnis/McPit-DCS-BIOS
- https://github.com/talbotmcinnis/TabletCDU
  - This one uses DCS-BIOS's export stream in Python/PyGame to render a CDU on a network connected windows tablet.